package com.rahmouni.tv

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextClock

class HomeActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val account = Store.account(this) ?: return openLogin()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(dp(16), dp(8), dp(16), dp(8))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(5, 20, 90), Color.rgb(20, 10, 60), Color.rgb(120, 0, 55)))
        }

        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brand.addView(Ui.text(this, "👑 Rahmouni Hocine Tv 👑", 24f, GOLD))
        brand.addView(Ui.text(this, "Visca el Barça ⚽", 15f, GOLD))
        top.addView(brand, Ui.params(0, -2, 1f))
        top.addView(TextClock(this).apply {
            format12Hour = "HH:mm\nMMM dd, yyyy"
            format24Hour = "HH:mm\nMMM dd, yyyy"
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }, Ui.params(-2, -2, 0f, dp(8)))
        top.addView(small("🔍 Recherche") { live("search") })
        top.addView(small("⚙") { settings() })
        root.addView(top)

        val middle = LinearLayout(this)
        val first = tile("📺\nTV EN DIRECT", Color.rgb(0, 190, 255), Color.rgb(0, 40, 200)) { live("watch") }
        middle.addView(first, Ui.params(0, -1, 1.1f, dp(5)))

        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val upper = LinearLayout(this)
        upper.addView(tile("🎬\nFILMS", Color.rgb(230, 20, 40), Color.rgb(255, 150, 0)) { browse(Kind.MOVIE) },
            Ui.params(0, -1, 1f, dp(5)))
        upper.addView(tile("🎞\nSERIES", Color.rgb(190, 0, 255), Color.rgb(70, 20, 220)) { browse(Kind.SERIES) },
            Ui.params(0, -1, 1f, dp(5)))
        right.addView(upper, Ui.params(-1, 0, 2f))
        val lower = LinearLayout(this)
        val green = Color.rgb(0, 140, 120)
        val light = Color.rgb(0, 200, 80)
        lower.addView(tile("LIVE AVEC EPG", green, light) { live("epg") }, Ui.params(0, -1, 1f, dp(5)))
        lower.addView(tile("MULTI-ÉCRANS", green, light) {
            startActivity(Intent(this, MultiActivity::class.java))
        }, Ui.params(0, -1, 1f, dp(5)))
        lower.addView(tile("RATTRAPER", green, light) { live("archive") }, Ui.params(0, -1, 1f, dp(5)))
        right.addView(lower, Ui.params(-1, 0, 1f))
        middle.addView(right, Ui.params(0, -1, 2f))
        root.addView(middle, Ui.params(-1, 0, 1f))

        val bottom = LinearLayout(this).apply {
            background = Ui.box(this@HomeActivity, Color.rgb(8, 8, 40), Color.rgb(20, 10, 55))
            setPadding(dp(12), dp(6), dp(12), dp(6))
        }
        bottom.addView(Ui.text(this, "📅 Expiration : ${account.expiry}", 14f))
        bottom.addView(View(this), Ui.params(0, 1, 1f))
        bottom.addView(Ui.text(this, "Connecté : ${account.name}", 14f, GOLD))
        root.addView(bottom, Ui.params(-1, -2, 0f, dp(5)))

        setContentView(root)
        first.requestFocus()
        recheck(account)
    }

    private fun tile(label: String, from: Int, to: Int, click: () -> Unit) =
        Ui.button(this, label, from, to, click).apply { textSize = 18f }

    private fun small(label: String, click: () -> Unit) =
        Ui.button(this, label, Color.TRANSPARENT, Color.TRANSPARENT, click)

    private fun live(mode: String) =
        startActivity(Intent(this, LiveActivity::class.java).putExtra("mode", mode))

    private fun browse(kind: Kind) =
        startActivity(Intent(this, BrowseActivity::class.java).putExtra("kind", kind.name))

    /** Codes are re-validated so that disabling one in the panel takes effect. */
    private fun recheck(account: Account) {
        val server = getString(R.string.activation_server)
        if (account.code.isEmpty() || server.isEmpty()) return
        val device = Store.deviceId(this)
        Task.run(this, { Activation.activate(server, account.code, device) }, { e ->
            // Network failures keep the saved account. A refusal logs out.
            if (e is ActivationError && e.status == 403) {
                toast(this, Activation.message(e.body))
                Store.logout(this)
                openLogin()
            }
        }) { fresh ->
            if (fresh != account) {
                Store.save(this, fresh)
                Session.reset()
                recreate()
            }
        }
    }

    private fun settings() {
        val items = arrayOf("حجم الشاشة: ${VideoBox.NAMES[Store.aspect(this)]}", "تسجيل الخروج", "حول التطبيق")
        AlertDialog.Builder(this).setTitle("الإعدادات").setItems(items) { _, i ->
            when (i) {
                0 -> AlertDialog.Builder(this).setTitle("حجم الشاشة")
                    .setItems(VideoBox.NAMES) { _, m -> Store.setAspect(this, m) }.show()
                1 -> { Store.logout(this); openLogin() }
                else -> AlertDialog.Builder(this).setTitle("Rahmouni Hocine Tv")
                    .setMessage("الإصدار 1.0\nمشغل فقط، لا يوفر أي قنوات أو اشتراكات.").show()
            }
        }.show()
    }

    private fun openLogin() {
        startActivity(Intent(this, LoginActivity::class.java))
        finish()
    }
}
