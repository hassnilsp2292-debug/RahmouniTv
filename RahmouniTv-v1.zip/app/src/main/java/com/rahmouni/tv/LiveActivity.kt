package com.rahmouni.tv

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView

/** Full screen live TV with a satellite receiver style channel list. */
class LiveActivity : Activity() {

    private lateinit var video: VideoBox
    private lateinit var panel: LinearLayout
    private lateinit var list: ListView
    private lateinit var header: TextView
    private lateinit var info: TextView
    private lateinit var size: View

    private var mode = "watch"
    private var all: List<Item> = emptyList()
    private var shown: List<Item> = emptyList()
    private var categories = listOf(Category("", "كل القنوات"), Category(FAVORITES, "★ المفضلة"))
    private var category = 0
    private var query = ""
    private var current: Item? = null
    private var url = ""
    private var request = 0
    private val handler = Handler(Looper.getMainLooper())
    private val hideInfo = Runnable { info.visibility = View.GONE }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mode = intent.getStringExtra("mode") ?: "watch"

        val root = FrameLayout(this).apply { layoutDirection = View.LAYOUT_DIRECTION_LTR }
        video = VideoBox(this)
        video.setOnClickListener { togglePanel(panel.visibility != View.VISIBLE) }
        video.view.setOnClickListener { togglePanel(panel.visibility != View.VISIBLE) }
        root.addView(video, FrameLayout.LayoutParams(-1, -1))

        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.argb(175, 0, 10, 30))
        }
        panel.addView(Ui.text(this, "👑 Rahmouni Tv", 22f, GOLD))
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        bar.addView(small("◀") { changeCategory(-1) })
        header = Ui.text(this, "قائمة القنوات", 15f)
        header.setOnClickListener { chooseCategory() }
        bar.addView(header, Ui.params(0, -2, 1f))
        bar.addView(small("▶") { changeCategory(1) })
        bar.addView(small("🔍") { search() })
        panel.addView(bar)
        list = ListView(this).apply {
            setSelector(Ui.box(this@LiveActivity, Color.argb(190, 0, 150, 255), Color.argb(90, 0, 80, 220)))
            isVerticalScrollBarEnabled = false
        }
        list.setOnItemClickListener { _, _, i, _ -> select(shown[i]) }
        list.setOnItemLongClickListener { _, _, i, _ ->
            val added = Store.toggleFavorite(this, shown[i].id)
            toast(this, if (added) "أضيفت إلى المفضلة" else "حذفت من المفضلة")
            if (categories[category].id == FAVORITES) refresh()
            true
        }
        panel.addView(list, Ui.params(-1, 0, 1f))
        root.addView(panel, FrameLayout.LayoutParams(dp(380), -1, Gravity.LEFT))

        info = Ui.text(this, "", 15f).apply {
            setBackgroundColor(Color.argb(190, 0, 10, 30))
            setPadding(dp(14), dp(8), dp(14), dp(8))
            visibility = View.GONE
        }
        root.addView(info, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.RIGHT))

        size = small("⛶ الحجم") { show(video.nextMode()) }
        root.addView(size, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.RIGHT))
        setContentView(root)

        header.text = "جار تحميل القنوات..."
        Task.run(this, {
            val s = Session.source(this)
            Pair(s.categories(Kind.LIVE), s.items(Kind.LIVE, ""))
        }, { e -> header.text = e.message ?: "تعذر التحميل" }) { (c, items) ->
            categories = categories + c
            all = items
            refresh()
            list.requestFocus()
            if (mode == "search") search()
        }
    }

    private fun small(label: String, click: () -> Unit) =
        Ui.button(this, label, Color.argb(150, 0, 60, 160), Color.argb(150, 0, 30, 90), click)
            .apply { minWidth = 0; minimumWidth = 0 }

    private fun refresh() {
        val c = categories[category]
        val favorites = Store.favorites(this)
        shown = all.filter {
            when (c.id) {
                "" -> true
                FAVORITES -> it.id in favorites
                else -> it.categoryId == c.id
            } && it.name.contains(query, true) && (mode != "archive" || it.hasArchive)
        }
        val adapter = ItemAdapter(this, shown, true)
        adapter.playingId = current?.id ?: ""
        list.adapter = adapter
        header.text = "قائمة القنوات | ${c.name} | ${shown.size}"
        if (mode == "archive" && shown.isEmpty()) header.text = "لا توجد قنوات تدعم الاستدراك"
        val i = shown.indexOfFirst { it.id == current?.id }
        if (i >= 0) list.setSelection(i)
    }

    private fun changeCategory(step: Int) {
        category = (category + step + categories.size) % categories.size
        refresh()
    }

    private fun chooseCategory() {
        val names = categories.map { it.name }.toTypedArray()
        AlertDialog.Builder(this).setTitle("الباقات")
            .setItems(names) { _, i -> category = i; refresh() }.show()
    }

    private fun search() {
        val input = EditText(this).apply { setSingleLine(); setText(query) }
        AlertDialog.Builder(this).setTitle("بحث عن قناة").setView(input)
            .setPositiveButton("بحث") { _, _ ->
                query = input.text.toString().trim()
                category = 0
                refresh()
            }
            .setNegativeButton("إلغاء", null).show()
    }

    private fun select(item: Item) {
        if (mode == "archive") return showArchive(item)
        // A second press on the playing channel hides the list.
        if (item.id == current?.id && video.player?.playerError == null) togglePanel(false) else tune(item)
    }

    private fun tune(item: Item) {
        current = item
        url = ""
        val id = ++request
        (list.adapter as? ItemAdapter)?.let { it.playingId = item.id; it.notifyDataSetChanged() }
        video.player?.stop()
        show(item.name)
        Task.run(this, { Session.source(this).link(Kind.LIVE, item) }) { link ->
            if (id == request) start(link)
        }
        if (mode == "epg") Task.run(this, { Session.source(this).epg(item) }, { }) { programs ->
            if (id == request) {
                val text = programs.take(4).joinToString("\n") { "${it.time}  ${it.title}" }
                show(item.name + "\n" + text.ifEmpty { "لا يوجد دليل برامج لهذه القناة" }, 12000)
            }
        }
    }

    private fun start(link: String) {
        url = link
        video.open { show("تعذر التشغيل: $it", 8000) }
        video.play(link)
    }

    private fun showArchive(item: Item) {
        Task.run(this, { Session.source(this).archive(item) }) { programs ->
            if (programs.isEmpty()) {
                toast(this, "لا توجد برامج مسجلة")
            } else {
                val names = programs.map { "${it.time}  ${it.title}" }.toTypedArray()
                AlertDialog.Builder(this).setTitle(item.name).setItems(names) { _, i ->
                    current = item
                    request++
                    try {
                        start(Session.source(this).archiveLink(item, programs[i]))
                        togglePanel(false)
                    } catch (e: Exception) {
                        toast(this, e.message ?: "تعذر التشغيل")
                    }
                }.show()
            }
        }
    }

    private fun show(text: String, time: Long = 3000) {
        info.text = text
        info.visibility = View.VISIBLE
        handler.removeCallbacks(hideInfo)
        handler.postDelayed(hideInfo, time)
    }

    private fun togglePanel(visible: Boolean) {
        panel.visibility = if (visible) View.VISIBLE else View.GONE
        size.visibility = panel.visibility
        if (visible) list.requestFocus()
    }

    private fun zap(step: Int) {
        if (shown.isEmpty()) return
        val i = shown.indexOfFirst { it.id == current?.id }
        val next = shown[(i + step + shown.size) % shown.size]
        tune(next)
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val hidden = panel.visibility != View.VISIBLE
        val key = event.keyCode
        val handled = when (key) {
            KeyEvent.KEYCODE_MENU -> true
            KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_CHANNEL_DOWN -> true
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN,
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> hidden
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT -> hidden || list.hasFocus()
            else -> false
        }
        if (!handled) return super.dispatchKeyEvent(event)
        if (event.action != KeyEvent.ACTION_DOWN) return true
        when (key) {
            KeyEvent.KEYCODE_MENU -> show(video.nextMode())
            KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_DPAD_UP -> zap(-1)
            KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_DPAD_DOWN -> zap(1)
            KeyEvent.KEYCODE_DPAD_LEFT -> if (!hidden) changeCategory(-1)
            KeyEvent.KEYCODE_DPAD_RIGHT -> if (!hidden) changeCategory(1)
            else -> togglePanel(true)
        }
        return true
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (panel.visibility == View.VISIBLE && current != null) togglePanel(false)
        else @Suppress("DEPRECATION") super.onBackPressed()
    }

    override fun onStart() {
        super.onStart()
        if (url.isNotEmpty()) start(url)
    }

    override fun onStop() {
        video.release()
        super.onStop()
    }

    private companion object {
        const val FAVORITES = "__fav"
    }
}
