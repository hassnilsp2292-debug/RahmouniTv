import base64, json, os, re, tempfile, threading, unittest
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from urllib.error import HTTPError

os.environ["DB_PATH"] = os.path.join(tempfile.mkdtemp(), "t.db")
os.environ["ADMIN_PASSWORD"] = "test-password"
import server

server.init()
httpd = server.ThreadingHTTPServer(("127.0.0.1", 0), server.Handler)
server.Handler.log_message = lambda *a: None
threading.Thread(target=httpd.serve_forever, daemon=True).start()
BASE = f"http://127.0.0.1:{httpd.server_address[1]}"
AUTH = {"Authorization": "Basic " + base64.b64encode(b"admin:test-password").decode()}


def call(path, data=None, headers=None):
    try:
        with urlopen(Request(BASE + path, data=data, headers=headers or {})) as r:
            return r.status, r.read().decode()
    except HTTPError as e:
        return e.code, e.read().decode()


def activate(code, device):
    s, b = call("/api/activate", json.dumps({"code": code, "device_id": device}).encode())
    return s, json.loads(b)


def admin(**f):
    f.setdefault("csrf", server.CSRF)
    return call("/admin", urlencode(f).encode(), AUTH)


class Test(unittest.TestCase):
    def setUp(self):
        server.ATTEMPTS.clear()

    def create(self, expires="2999-01-01", limit=1):
        _, body = admin(action="create", name="<b>x</b>", type="xtream", url="host:80",
                        username="u", password="p", expires=expires, max_devices=limit)
        return re.search(r"الكود الجديد: (\w+)", body).group(1), body

    def test_flow(self):
        code, body = self.create()
        self.assertNotIn("<b>x</b>", body)
        status, data = activate(code.lower(), "a")
        self.assertEqual((status, data["url"]), (200, "http://host:80"))
        self.assertEqual(activate(code, "a")[0], 200)
        self.assertEqual(activate(code, "b")[1]["error"], "device_limit")
        admin(action="reset", code=code)
        self.assertEqual(activate(code, "b")[0], 200)
        admin(action="toggle", code=code)
        self.assertEqual(activate(code, "b")[1]["error"], "disabled")
        admin(action="delete", code=code)
        self.assertEqual(activate(code, "b")[1]["error"], "invalid")

    def test_expired(self):
        code, _ = self.create(expires="2000-01-01")
        self.assertEqual(activate(code, "a")[1]["error"], "expired")

    def test_security(self):
        self.assertEqual(call("/admin")[0], 401)
        self.assertEqual(admin(action="create", csrf="bad")[0], 403)
        self.assertEqual(call("/api/activate", b"[]")[0], 400)
        for _ in range(server.MAX_FAILS):
            activate("NOPE", "a")
        self.assertEqual(activate("NOPE", "a")[0], 429)


if __name__ == "__main__":
    unittest.main()
