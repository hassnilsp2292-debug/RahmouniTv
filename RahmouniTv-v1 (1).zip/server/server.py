#!/usr/bin/env python3
"""Rahmouni Tv activation server and control panel (Python standard library only)."""
import base64, datetime, hashlib, hmac, html, json, os, secrets, sqlite3, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs

DB = os.environ.get("DB_PATH", "rahmouni.db")
ADMIN_USER = os.environ.get("ADMIN_USER", "admin")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "")
CSRF = secrets.token_hex(24)
ATTEMPTS = {}          # ip -> times of failed requests
MAX_FAILS, WINDOW = 10, 300


def db():
    c = sqlite3.connect(DB, timeout=10)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    return c


def init():
    c = db()
    with c:
        c.execute("""CREATE TABLE IF NOT EXISTS codes(
            code TEXT PRIMARY KEY, name TEXT, type TEXT, url TEXT, username TEXT,
            password TEXT, mac TEXT, expires TEXT, max_devices INTEGER, active INTEGER DEFAULT 1)""")
        c.execute("""CREATE TABLE IF NOT EXISTS devices(
            code TEXT REFERENCES codes(code) ON DELETE CASCADE, device_id TEXT,
            last_seen TEXT, PRIMARY KEY(code, device_id))""")
    c.close()


def activate(code, device):
    """Returns (status, body)."""
    c = db()
    try:
        with c:
            c.execute("BEGIN IMMEDIATE")  # so two devices cannot take the last slot
            r = c.execute("SELECT * FROM codes WHERE code=?", (code,)).fetchone()
            if r is None:
                return 403, {"error": "invalid"}
            if not r["active"]:
                return 403, {"error": "disabled"}
            if r["expires"] < datetime.date.today().isoformat():
                return 403, {"error": "expired"}
            known = c.execute("SELECT 1 FROM devices WHERE code=? AND device_id=?", (code, device)).fetchone()
            if not known:
                used = c.execute("SELECT COUNT(*) FROM devices WHERE code=?", (code,)).fetchone()[0]
                if used >= r["max_devices"]:
                    return 403, {"error": "device_limit"}
            now = datetime.datetime.now().isoformat(" ", "minutes")
            c.execute("INSERT OR REPLACE INTO devices VALUES(?,?,?)", (code, device, now))
            keys = ("name", "type", "url", "username", "password", "mac", "expires")
            return 200, {k: r[k] for k in keys}
    finally:
        c.close()


def new_code():
    alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    return "".join(secrets.choice(alphabet) for _ in range(12))


def admin_action(form):
    f = {k: v[0].strip() for k, v in form.items()}
    action, code = f.get("action"), f.get("code", "")
    c = db()
    try:
        with c:
            if action == "create":
                kind = f.get("type")
                need = ["name", "url", "expires"] + (["mac"] if kind == "stalker" else ["username", "password"])
                if kind not in ("xtream", "stalker") or any(not f.get(k) for k in need):
                    return "املأ كل الحقول المطلوبة"
                expires = datetime.date.fromisoformat(f["expires"]).isoformat()
                limit = max(1, int(f.get("max_devices") or 1))
                url = f["url"] if f["url"].startswith(("http://", "https://")) else "http://" + f["url"]
                code = new_code()
                c.execute("INSERT INTO codes VALUES(?,?,?,?,?,?,?,?,?,1)",
                          (code, f["name"], kind, url, f.get("username", ""), f.get("password", ""),
                           f.get("mac", ""), expires, limit))
                return "الكود الجديد: " + code
            if action == "toggle":
                c.execute("UPDATE codes SET active=1-active WHERE code=?", (code,))
            elif action == "delete":
                c.execute("DELETE FROM codes WHERE code=?", (code,))
            elif action == "reset":
                c.execute("DELETE FROM devices WHERE code=?", (code,))
            elif action == "update":
                expires = datetime.date.fromisoformat(f.get("expires", "")).isoformat()
                limit = max(1, int(f.get("max_devices") or 1))
                c.execute("UPDATE codes SET expires=?, max_devices=? WHERE code=?", (expires, limit, code))
            return "تم"
    except ValueError:
        return "تاريخ أو عدد غير صالح"
    finally:
        c.close()


def page(message=""):
    e = lambda v: html.escape(str(v), quote=True)
    c = db()
    rows = c.execute("""SELECT codes.*, COUNT(devices.device_id) AS used, MAX(devices.last_seen) AS seen
        FROM codes LEFT JOIN devices USING(code) GROUP BY codes.code ORDER BY codes.rowid DESC""").fetchall()
    c.close()

    def form(code, action, label, extra=""):
        return (f'<form method="post"><input type="hidden" name="csrf" value="{CSRF}">'
                f'<input type="hidden" name="code" value="{e(code)}">'
                f'<input type="hidden" name="action" value="{action}">{extra}<button>{label}</button></form>')

    body = ""
    for r in rows:
        state = "موقوف" if not r["active"] else (
            "منتهي" if r["expires"] < datetime.date.today().isoformat() else "يعمل")
        edit = (f'<input type="date" name="expires" value="{e(r["expires"])}">'
                f'<input type="number" name="max_devices" min="1" value="{r["max_devices"]}">')
        body += (f'<tr><td><b>{e(r["code"])}</b></td><td>{e(r["name"])}</td><td>{e(r["type"])}</td>'
                 f'<td>{state}</td><td>{r["used"]}/{r["max_devices"]}</td><td>{e(r["seen"] or "-")}</td>'
                 f'<td>{form(r["code"], "update", "حفظ", edit)}'
                 f'{form(r["code"], "toggle", "إيقاف" if r["active"] else "تفعيل")}'
                 f'{form(r["code"], "reset", "تصفير الأجهزة")}{form(r["code"], "delete", "حذف")}</td></tr>')

    return f"""<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Rahmouni Tv</title><style>
body{{font-family:sans-serif;background:#0b1030;color:#fff;margin:16px}}h1{{color:#fc3}}
input,select,button{{padding:8px;margin:3px;border-radius:6px;border:0}}button{{background:#fc3;cursor:pointer}}
.t{{overflow-x:auto}}table{{border-collapse:collapse;width:100%}}td,th{{border:1px solid #345;padding:6px}}
form{{display:inline}}</style></head><body><h1>👑 Rahmouni Hocine Tv</h1><p><b>{e(message)}</b></p>
<h2>كود جديد</h2><form method="post"><input type="hidden" name="csrf" value="{CSRF}">
<input type="hidden" name="action" value="create"><input name="name" placeholder="اسم المستخدم (الزبون)" required>
<select name="type"><option value="xtream">Xtream</option><option value="stalker">Stalker</option></select>
<input name="url" placeholder="رابط الخادم أو البوابة" required>
<input name="username" placeholder="Xtream username"><input name="password" placeholder="Xtream password">
<input name="mac" placeholder="Stalker MAC">
<label>ينتهي <input type="date" name="expires" required></label>
<label>الأجهزة <input type="number" name="max_devices" value="1" min="1"></label><button>إنشاء</button></form>
<h2>الأكواد</h2><div class="t"><table><tr><th>الكود</th><th>الاسم</th><th>النوع</th><th>الحالة</th>
<th>الأجهزة</th><th>آخر دخول</th><th>التحكم</th></tr>{body}</table></div></body></html>"""


class Handler(BaseHTTPRequestHandler):
    timeout = 20

    def send(self, status, body, kind="application/json", headers=()):
        data = (json.dumps(body) if kind == "application/json" else body).encode()
        self.send_response(status)
        self.send_header("Content-Type", kind + "; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Frame-Options", "DENY")
        for k, v in headers:
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(data)

    def ip(self):
        # Behind a trusted reverse proxy set TRUST_PROXY=1 to read the real address.
        forwarded = self.headers.get("X-Forwarded-For")
        if os.environ.get("TRUST_PROXY") == "1" and forwarded:
            return forwarded.split(",")[-1].strip()
        return self.client_address[0]

    def blocked(self):
        now = time.time()
        recent = [t for t in ATTEMPTS.get(self.ip(), []) if now - t < WINDOW]
        ATTEMPTS[self.ip()] = recent
        return len(recent) >= MAX_FAILS

    def fail(self):
        ATTEMPTS.setdefault(self.ip(), []).append(time.time())

    def admin(self):
        header = self.headers.get("Authorization", "")
        if self.blocked():
            self.send(429, {"error": "slow_down"})
            return False
        expected = "Basic " + base64.b64encode(f"{ADMIN_USER}:{ADMIN_PASSWORD}".encode()).decode()
        if hmac.compare_digest(header.encode(), expected.encode()):
            return True
        if header:
            self.fail()
        self.send(401, "Unauthorized", "text/plain", [("WWW-Authenticate", 'Basic realm="admin"')])
        return False

    def do_GET(self):
        if self.path in ("/", "/admin"):
            if self.admin():
                self.send(200, page(), "text/html")
        else:
            self.send(404, {"error": "not_found"})

    def do_POST(self):
        try:
            length = int(self.headers.get("Content-Length", 0))
        except ValueError:
            length = -1
        if not 0 <= length <= 10000:
            return self.send(400, {"error": "bad_request"})
        raw = self.rfile.read(length).decode("utf-8", "replace")
        if self.path == "/api/activate":
            if self.blocked():
                return self.send(429, {"error": "slow_down"})
            try:
                data = json.loads(raw)
                code = str(data["code"]).strip().upper()
                device = str(data["device_id"]).strip()[:100]
                assert code and device
            except Exception:
                return self.send(400, {"error": "bad_request"})
            status, body = activate(code, device)
            if body.get("error") == "invalid":
                self.fail()
            return self.send(status, body)
        if self.path in ("/", "/admin"):
            if not self.admin():
                return
            form = parse_qs(raw)
            if not hmac.compare_digest(form.get("csrf", [""])[0].encode(), CSRF.encode()):
                return self.send(403, "أعد تحميل الصفحة", "text/plain")
            return self.send(200, page(admin_action(form)), "text/html")
        self.send(404, {"error": "not_found"})


if __name__ == "__main__":
    if len(ADMIN_PASSWORD) < 8:
        raise SystemExit("Set ADMIN_PASSWORD (8 characters or more) first.")
    init()
    port = int(os.environ.get("PORT", 8080))
    print(f"Panel on http://localhost:{port}/admin")
    ThreadingHTTPServer((os.environ.get("HOST", "0.0.0.0"), port), Handler).serve_forever()
