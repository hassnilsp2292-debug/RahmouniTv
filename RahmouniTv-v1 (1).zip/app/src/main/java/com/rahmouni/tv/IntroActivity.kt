package com.rahmouni.tv

import android.app.Activity
import android.content.Intent
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout

class IntroActivity : Activity() {

    private var player: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())
    private val goNext = Runnable { openNext() }
    private var finished = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this)
        root.addView(IntroView(this))

        val skip = Button(this).apply {
            setText(R.string.skip)
            setOnClickListener { openNext() }
        }
        val margin = (24 * resources.displayMetrics.density).toInt()
        root.addView(skip, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.END
        ).apply { setMargins(margin, margin, margin, margin) })

        setContentView(root)
        skip.requestFocus()
    }

    override fun onResume() {
        super.onResume()
        hideSystemBars()
        if (player == null) player = MediaPlayer.create(this, R.raw.intro)
        player?.start()
        handler.postDelayed(goNext, DURATION_MS)
    }

    override fun onPause() {
        handler.removeCallbacks(goNext)
        player?.pause()
        super.onPause()
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }

    private fun openNext() {
        if (finished) return
        finished = true
        handler.removeCallbacks(goNext)
        val next = if (Store.account(this) == null) LoginActivity::class.java else HomeActivity::class.java
        startActivity(Intent(this, next))
        finish()
    }

    @Suppress("DEPRECATION")
    private fun hideSystemBars() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
    }

    private companion object {
        const val DURATION_MS = 6000L
    }
}
