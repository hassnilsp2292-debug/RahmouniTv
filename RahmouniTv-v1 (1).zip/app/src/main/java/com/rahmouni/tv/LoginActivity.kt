package com.rahmouni.tv

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView

class LoginActivity : Activity() {

    private lateinit var form: LinearLayout
    private lateinit var status: android.widget.TextView
    private var mode = "code"
    private val fields = mutableMapOf<String, EditText>()
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), dp(12))
            background = Ui.box(this@LoginActivity, Color.argb(215, 8, 10, 35),
                Color.argb(215, 8, 10, 35), GOLD)
        }
        card.addView(Ui.text(this, "👑 Rahmouni Hocine Tv 👑", 26f, GOLD))

        val tabs = LinearLayout(this)
        listOf("code" to "كود التفعيل", "xtream" to "Xtream", "stalker" to "Stalker").forEach { (key, label) ->
            tabs.addView(Ui.button(this, label, Color.rgb(0, 77, 152), Color.rgb(165, 0, 68)) { show(key) },
                Ui.params(0, -2, 1f, dp(4)))
        }
        card.addView(tabs)

        form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        card.addView(form)
        card.addView(Ui.button(this, "دخول", Color.rgb(200, 140, 0), Color.rgb(255, 200, 50)) { submit() },
            Ui.params(-1, -2, 0f, dp(4)))
        status = Ui.text(this, "", 14f)
        card.addView(status)

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            background = Stadium()
        }
        val holder = LinearLayout(this).apply { gravity = Gravity.CENTER }
        holder.addView(card, LinearLayout.LayoutParams(dp(460), -2).apply { setMargins(dp(12), dp(8), dp(12), dp(8)) })
        scroll.addView(holder)
        setContentView(scroll)
        show("code")
    }

    private fun show(key: String) {
        mode = key
        form.removeAllViews()
        fields.clear()
        status.text = ""
        when (key) {
            "code" -> field("code", "أدخل كود التفعيل")
            "xtream" -> {
                field("name", "اسم الحساب")
                field("url", "رابط الخادم  http://host:port")
                field("user", "اسم المستخدم")
                field("pass", "كلمة المرور", true)
            }
            else -> {
                field("name", "اسم الحساب")
                field("url", "رابط البوابة  http://host:port/c/")
                field("mac", "عنوان MAC  00:1A:79:XX:XX:XX")
            }
        }
        fields.values.firstOrNull()?.requestFocus()
    }

    private fun field(key: String, hint: String, secret: Boolean = false) {
        val e = EditText(this).apply {
            this.hint = hint
            setHintTextColor(Color.LTGRAY)
            setTextColor(Color.WHITE)
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS or
                (if (secret) InputType.TYPE_TEXT_VARIATION_PASSWORD else InputType.TYPE_TEXT_VARIATION_URI)
            textDirection = View.TEXT_DIRECTION_LOCALE
        }
        fields[key] = e
        form.addView(e, Ui.params(-1, -2))
    }

    private fun value(key: String) = fields[key]?.text?.toString()?.trim() ?: ""

    private fun submit() {
        if (busy) return
        val selected = mode
        val required = when (selected) {
            "code" -> listOf("code")
            "xtream" -> listOf("url", "user", "pass")
            else -> listOf("url", "mac")
        }
        if (required.any { value(it).isEmpty() }) {
            status.text = "املأ كل الحقول"
            return
        }
        var url = value("url")
        if (url.isNotEmpty() && !url.startsWith("http")) url = "http://$url"
        val code = value("code")
        val manual = Account(selected, value("name").ifEmpty { value("user").ifEmpty { "Stalker" } },
            url, value("user"), value("pass"), value("mac"))
        val server = getString(R.string.activation_server)
        if (selected == "code" && server.isEmpty()) {
            status.text = "لم يتم ضبط رابط خادم التفعيل في التطبيق"
            return
        }
        val device = Store.deviceId(this)
        busy = true
        status.text = "جار الاتصال..."
        Task.run(this, {
            val account = if (selected == "code") Activation.activate(server, code, device) else manual
            val expiry = Source.of(account).login()
            // A code keeps the expiry date set in our control panel.
            if (selected == "code") account else account.copy(expiry = expiry)
        }, { e ->
            busy = false
            status.text = if (e is ActivationError) Activation.message(e.body)
            else e.message ?: "تعذر الاتصال"
        }) { account ->
            Session.reset()
            Store.save(this, account)
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
        }
    }
}
