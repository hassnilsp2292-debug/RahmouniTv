package com.rahmouni.tv

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.widget.FrameLayout
import android.widget.LinearLayout

/** Four channels at once. Only the selected screen has sound. */
class MultiActivity : Activity() {

    private val boxes = mutableListOf<VideoBox>()
    private val urls = arrayOfNulls<String>(4)
    private var channels: List<Item> = emptyList()
    private var active = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        for (r in 0..1) {
            val row = LinearLayout(this)
            for (col in 0..1) {
                val i = r * 2 + col
                val cell = FrameLayout(this).apply {
                    setPadding(dp(3), dp(3), dp(3), dp(3))
                    background = Ui.focusable(this@MultiActivity, Color.DKGRAY, Color.DKGRAY)
                }
                val box = VideoBox(this)
                boxes.add(box)
                cell.addView(box)
                val button = Ui.button(this, "＋", Color.TRANSPARENT, Color.TRANSPARENT) { press(i) }
                button.setOnLongClickListener { choose(i); true }
                button.setOnFocusChangeListener { _, focused -> if (focused) listen(i) }
                cell.addView(button, FrameLayout.LayoutParams(-1, -1))
                row.addView(cell, Ui.params(0, -1, 1f))
            }
            root.addView(row, Ui.params(-1, 0, 1f))
        }
        setContentView(root)
        toast(this, "اضغط لاختيار قناة، واضغط مطولا لتغييرها")
        Task.run(this, { Session.source(this).items(Kind.LIVE, "") }) { channels = it }
    }

    private fun press(i: Int) {
        // First press on a playing screen selects its sound, the next one changes channel.
        if (urls[i] == null || active == i) choose(i) else listen(i)
    }

    private fun listen(i: Int) {
        active = i
        boxes.forEachIndexed { n, b -> b.player?.volume = if (n == i) 1f else 0f }
    }

    private fun choose(i: Int) {
        if (channels.isEmpty()) return toast(this, "جار تحميل القنوات...")
        AlertDialog.Builder(this).setTitle("اختر قناة")
            .setItems(channels.map { it.name }.toTypedArray()) { _, n ->
                Task.run(this, { Session.source(this).link(Kind.LIVE, channels[n]) }) {
                    urls[i] = it
                    ((boxes[i].parent as FrameLayout).getChildAt(1) as android.widget.Button).text = ""
                    start(i)
                    listen(i)
                }
            }.show()
    }

    private fun start(i: Int) {
        val url = urls[i] ?: return
        boxes[i].open { toast(this, "تعذر التشغيل، قد لا يسمح اشتراكك بعدة اتصالات") }
        boxes[i].play(url)
    }

    override fun onStart() {
        super.onStart()
        for (i in 0..3) start(i)
        listen(active)
    }

    override fun onStop() {
        boxes.forEach { it.release() }
        super.onStop()
    }
}
