package com.rahmouni.tv

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView

/** Movies and series: categories on the left, titles on the right. */
class BrowseActivity : Activity() {

    private lateinit var kind: Kind
    private lateinit var list: ListView
    private lateinit var status: android.widget.TextView
    private lateinit var search: EditText
    private var items: List<Item> = emptyList()
    private var shown: List<Item> = emptyList()
    private var request = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        kind = Kind.valueOf(intent.getStringExtra("kind") ?: Kind.MOVIE.name)

        val root = LinearLayout(this).apply {
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setBackgroundColor(Color.rgb(8, 12, 45))
        }
        val categories = ListView(this)
        root.addView(categories, Ui.params(0, -1, 1f))

        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        status = Ui.text(this, if (kind == Kind.MOVIE) "FILMS" else "SERIES", 20f, GOLD)
        right.addView(status)
        search = EditText(this).apply {
            hint = "بحث"
            setSingleLine()
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) = filter()
        })
        right.addView(search)
        list = ListView(this)
        list.setOnItemClickListener { _, _, i, _ -> open(shown[i]) }
        right.addView(list, Ui.params(-1, 0, 1f))
        root.addView(right, Ui.params(0, -1, 2f))
        setContentView(root)

        Task.run(this, { Session.source(this).categories(kind) }, { fail(it) }) { result ->
            categories.adapter = object : ArrayAdapter<String>(
                this, android.R.layout.simple_list_item_1, result.map { it.name }) {
                override fun getView(p: Int, v: View?, parent: android.view.ViewGroup): View =
                    super.getView(p, v, parent).also {
                        (it as android.widget.TextView).setTextColor(Color.WHITE)
                    }
            }
            categories.setOnItemClickListener { _, _, i, _ -> load(result[i]) }
            categories.requestFocus()
            result.firstOrNull()?.let { load(it) }
        }
    }

    private fun fail(e: Exception) {
        status.text = e.message ?: "تعذر التحميل"
    }

    private fun load(category: Category) {
        val id = ++request
        status.text = "جار التحميل..."
        Task.run(this, { Session.source(this).items(kind, category.id) }, { fail(it) }) {
            if (id == request) {
                items = it
                status.text = "${category.name} (${it.size})"
                filter()
            }
        }
    }

    private fun filter() {
        val q = search.text.toString().trim()
        shown = items.filter { it.name.contains(q, true) }
        list.adapter = ItemAdapter(this, shown, false)
    }

    private fun open(item: Item) {
        if (kind == Kind.MOVIE) return play(item)
        Task.run(this, { Session.source(this).episodes(item) }) { episodes ->
            if (episodes.isEmpty()) {
                toast(this, "لا توجد حلقات")
            } else {
                AlertDialog.Builder(this).setTitle(item.name)
                    .setItems(episodes.map { it.name }.toTypedArray()) { _, i -> play(episodes[i]) }.show()
            }
        }
    }

    private fun play(item: Item) {
        startActivity(
            Intent(this, PlayerActivity::class.java)
                .putExtra("kind", kind.name).putExtra("id", item.id).putExtra("name", item.name)
                .putExtra("extra", item.extra).putExtra("episode", item.episode)
        )
    }
}
