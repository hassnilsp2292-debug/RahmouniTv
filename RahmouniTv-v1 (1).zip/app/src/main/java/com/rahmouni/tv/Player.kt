package com.rahmouni.tv

import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.widget.FrameLayout
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView

/** A video surface with the screen size modes. */
class VideoBox(context: Context) : FrameLayout(context) {
    val view = PlayerView(context)
    var player: ExoPlayer? = null
        private set
    private var mode = Store.aspect(context)

    init {
        setBackgroundColor(Color.BLACK)
        view.useController = false
        view.isFocusable = false
        view.keepScreenOn = true
        addView(view, LayoutParams(-1, -1, Gravity.CENTER))
    }

    fun open(onError: (String) -> Unit): ExoPlayer {
        player?.let { return it }
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(MAG_AGENT)
            .setAllowCrossProtocolRedirects(true)
        val p = ExoPlayer.Builder(context)
            .setMediaSourceFactory(DefaultMediaSourceFactory(context).setDataSourceFactory(http))
            .build()
        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) = onError(error.errorCodeName)
        })
        view.player = p
        player = p
        return p
    }

    fun play(url: String, position: Long = 0) {
        val p = player ?: return
        p.setMediaItem(MediaItem.fromUri(url), position)
        p.prepare()
        p.playWhenReady = true
    }

    fun release() {
        view.player = null
        player?.release()
        player = null
    }

    fun nextMode(): String {
        mode = (mode + 1) % NAMES.size
        Store.setAspect(context, mode)
        applyMode(width, height)
        return NAMES[mode]
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        post { applyMode(width, height) }
    }

    private fun applyMode(w: Int, h: Int) {
        if (w == 0 || h == 0) return
        val ratio = when (mode) { 3 -> 16f / 9f; 4 -> 4f / 3f; else -> 0f }
        var vw = -1
        var vh = -1
        if (ratio > 0) {
            if (w / ratio <= h) { vw = w; vh = (w / ratio).toInt() } else { vh = h; vw = (h * ratio).toInt() }
        }
        view.resizeMode = when (mode) {
            0 -> AspectRatioFrameLayout.RESIZE_MODE_FIT
            1 -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
            else -> AspectRatioFrameLayout.RESIZE_MODE_FILL
        }
        view.layoutParams = LayoutParams(vw, vh, Gravity.CENTER)
    }

    companion object {
        val NAMES = arrayOf("ملاءمة", "ملء", "تمديد", "16:9", "4:3")
    }
}
