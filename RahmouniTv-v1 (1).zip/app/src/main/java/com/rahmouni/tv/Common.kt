package com.rahmouni.tv

import android.app.Activity
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.LruCache
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AbsListView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

val GOLD = Color.rgb(255, 204, 51)

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

object Store {
    private fun prefs(c: Context) = c.getSharedPreferences("rht", Context.MODE_PRIVATE)

    fun save(c: Context, a: Account) {
        val o = JSONObject().put("type", a.type).put("name", a.name).put("url", a.url)
            .put("user", a.user).put("pass", a.pass).put("mac", a.mac)
            .put("code", a.code).put("expiry", a.expiry)
        prefs(c).edit().putString("account", o.toString()).apply()
    }

    fun account(c: Context): Account? {
        val s = prefs(c).getString("account", null) ?: return null
        val o = JSONObject(s)
        return Account(
            o.optString("type"), o.optString("name"), o.optString("url"), o.optString("user"),
            o.optString("pass"), o.optString("mac"), o.optString("code"), o.optString("expiry")
        )
    }

    fun logout(c: Context) {
        prefs(c).edit().clear().apply()
        Session.reset()
    }

    fun aspect(c: Context): Int = prefs(c).getInt("aspect", 0)
    fun setAspect(c: Context, v: Int) = prefs(c).edit().putInt("aspect", v).apply()

    fun favorites(c: Context): Set<String> = prefs(c).getStringSet("favorites", emptySet())!!.toSet()

    fun toggleFavorite(c: Context, id: String): Boolean {
        val set = favorites(c).toMutableSet()
        val added = set.add(id)
        if (!added) set.remove(id)
        prefs(c).edit().putStringSet("favorites", set).apply()
        return added
    }

    fun position(c: Context, key: String): Long = prefs(c).getLong("pos_$key", 0)
    fun setPosition(c: Context, key: String, v: Long) = prefs(c).edit().putLong("pos_$key", v).apply()

    @Suppress("HardwareIds")
    fun deviceId(c: Context): String =
        Settings.Secure.getString(c.contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"
}

object Session {
    private var source: Source? = null

    @Synchronized
    fun source(c: Context): Source =
        source ?: Source.of(Store.account(c) ?: throw Exception("سجل الدخول أولا")).also { source = it }

    @Synchronized
    fun reset() { source = null }
}

object Task {
    private val pool = Executors.newFixedThreadPool(4)
    private val main = Handler(Looper.getMainLooper())

    /** Runs work in the background and delivers the result if the screen is still open. */
    fun <T> run(a: Activity, work: () -> T, fail: ((Exception) -> Unit)? = null, done: (T) -> Unit) {
        pool.execute {
            try {
                val result = work()
                main.post { if (!a.isFinishing && !a.isDestroyed) done(result) }
            } catch (e: Exception) {
                main.post {
                    if (!a.isFinishing && !a.isDestroyed) {
                        if (fail != null) fail(e) else toast(a, e.message ?: "خطأ في الاتصال")
                    }
                }
            }
        }
    }
}

fun toast(c: Context, text: String) = Toast.makeText(c, text, Toast.LENGTH_LONG).show()

object Images {
    private val cache = object : LruCache<String, Bitmap>(16 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount / 1024
    }
    private val pool = Executors.newFixedThreadPool(4)
    private val main = Handler(Looper.getMainLooper())

    fun load(view: ImageView, url: String) {
        view.tag = url
        view.setImageResource(R.drawable.ic_crown)
        if (!url.startsWith("http")) return
        cache.get(url)?.let { view.setImageBitmap(it); return }
        pool.execute {
            // Skip rows that were recycled while waiting.
            if (view.tag != url) return@execute
            try {
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 8000
                c.readTimeout = 8000
                val bytes = c.inputStream.use { it.readBytes() }
                val size = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, size)
                var sample = 1
                while (size.outWidth / sample > 400) sample *= 2
                val options = BitmapFactory.Options().apply { inSampleSize = sample }
                val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options) ?: return@execute
                cache.put(url, bitmap)
                main.post { if (view.tag == url) view.setImageBitmap(bitmap) }
            } catch (e: Exception) {
                // Keep the placeholder.
            }
        }
    }
}

object Ui {
    fun box(c: Context, from: Int, to: Int, stroke: Int = 0): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(from, to)).apply {
            cornerRadius = c.dp(12).toFloat()
            if (stroke != 0) setStroke(c.dp(3), stroke)
        }

    /** Background with a visible focus frame for the remote control. */
    fun focusable(c: Context, from: Int, to: Int): StateListDrawable = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_pressed), box(c, from, to, GOLD))
        addState(intArrayOf(android.R.attr.state_focused), box(c, from, to, GOLD))
        addState(intArrayOf(), box(c, from, to))
    }

    fun text(c: Context, value: String, size: Float, color: Int = Color.WHITE) = TextView(c).apply {
        text = value
        textSize = size
        setTextColor(color)
        gravity = Gravity.CENTER
    }

    fun button(c: Context, value: String, from: Int, to: Int, click: () -> Unit) = Button(c).apply {
        text = value
        isAllCaps = false
        setTextColor(Color.WHITE)
        textSize = 16f
        background = focusable(c, from, to)
        setPadding(c.dp(12), c.dp(6), c.dp(12), c.dp(6))
        setOnClickListener { click() }
    }

    fun params(w: Int, h: Int, weight: Float = 0f, margin: Int = 0) =
        LinearLayout.LayoutParams(w, h, weight).apply { setMargins(margin, margin, margin, margin) }
}

/** List rows: number, logo, name and signal bars, like a satellite receiver. */
class ItemAdapter(
    private val c: Context,
    private val rows: List<Item>,
    private val numbered: Boolean
) : ArrayAdapter<Item>(c, 0, rows) {
    var playingId = ""

    private fun label(size: Float) = Ui.text(c, "", size).apply {
        gravity = Gravity.START or Gravity.CENTER_VERTICAL
        maxLines = 1
        setShadowLayer(6f, 2f, 2f, Color.BLACK)
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val row = convertView as? LinearLayout ?: LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            addView(label(17f), LinearLayout.LayoutParams(c.dp(64), -2))
            addView(ImageView(c), LinearLayout.LayoutParams(c.dp(48), c.dp(26)))
            addView(label(17f), LinearLayout.LayoutParams(0, -2, 1f))
            addView(ImageView(c).apply { setImageResource(R.drawable.signal) },
                LinearLayout.LayoutParams(c.dp(28), c.dp(22)))
        }
        // Ten channels fill the screen.
        val height = if (numbered) maxOf(parent.height / 10, c.dp(30)) else c.dp(48)
        row.layoutParams = AbsListView.LayoutParams(-1, height)
        row.background = if (numbered && rows[position].id == playingId)
            Ui.box(c, Color.argb(200, 0, 140, 255), Color.argb(60, 0, 80, 220), Color.rgb(90, 200, 255))
        else null
        row.setPadding(c.dp(10), 0, c.dp(10), 0)
        val item = rows[position]
        val number = row.getChildAt(0) as TextView
        number.text = "%04d".format(position + 1)
        number.visibility = if (numbered) View.VISIBLE else View.GONE
        val logo = row.getChildAt(1) as ImageView
        Images.load(logo, item.logo)
        val name = row.getChildAt(2) as TextView
        name.text = item.name
        name.setPadding(c.dp(16), 0, 0, 0)
        row.getChildAt(3).visibility = if (numbered) View.VISIBLE else View.GONE
        return row
    }
}
