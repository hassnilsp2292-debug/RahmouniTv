package com.rahmouni.tv

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class Kind { LIVE, MOVIE, SERIES }

data class Category(val id: String, val name: String)

data class Item(
    val id: String,
    val name: String,
    val logo: String = "",
    val number: Int = 0,
    val categoryId: String = "",
    /** Xtream: file extension. Stalker: portal command. */
    val extra: String = "",
    val hasArchive: Boolean = false,
    /** Stalker series episode number. */
    val episode: String = ""
)

data class Program(val title: String, val time: String, val start: String = "", val minutes: Int = 0)

data class Account(
    val type: String,
    val name: String,
    val url: String,
    val user: String = "",
    val pass: String = "",
    val mac: String = "",
    val code: String = "",
    val expiry: String = ""
)

interface Source {
    /** Checks the account and returns the expiry text. */
    fun login(): String
    fun categories(kind: Kind): List<Category>
    /** categoryId "" means everything. */
    fun items(kind: Kind, categoryId: String): List<Item>
    fun episodes(series: Item): List<Item>
    fun link(kind: Kind, item: Item): String
    fun epg(item: Item): List<Program>
    fun archive(item: Item): List<Program>
    fun archiveLink(item: Item, program: Program): String

    companion object {
        fun of(a: Account): Source = if (a.type == "stalker") Stalker(a) else Xtream(a)
    }
}

const val MAG_AGENT = "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 " +
    "(KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"

object Http {
    fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    fun request(url: String, headers: Map<String, String> = emptyMap(), body: String? = null): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 40000
        c.setRequestProperty("User-Agent", "RahmouniTv/1.0")
        headers.forEach { c.setRequestProperty(it.key, it.value) }
        try {
            if (body != null) {
                c.requestMethod = "POST"
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(body.toByteArray()) }
            }
            val status = c.responseCode
            val stream = if (status < 400) c.inputStream else c.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (status >= 400) throw ApiError(status, text)
            return text
        } finally {
            c.disconnect()
        }
    }
}

open class ApiError(val status: Int, val body: String) : Exception("خطأ من الخادم ($status)")

private fun JSONArray?.objects(): List<JSONObject> =
    if (this == null) emptyList() else (0 until length()).mapNotNull { optJSONObject(it) }

private fun JSONObject.str(key: String): String =
    if (isNull(key)) "" else optString(key, "")

private fun formatSeconds(seconds: Long): String =
    SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(seconds * 1000))

private fun clock(seconds: Long): String =
    SimpleDateFormat("HH:mm", Locale.US).format(Date(seconds * 1000))

class Xtream(private val a: Account) : Source {
    private val base = a.url.trim().trimEnd('/').removeSuffix("/player_api.php")
    private val path get() = "${Uri.part(a.user)}/${Uri.part(a.pass)}"

    private fun call(query: String): String = Http.request(
        "$base/player_api.php?username=${Http.enc(a.user)}&password=${Http.enc(a.pass)}$query"
    )

    override fun login(): String {
        val info = JSONObject(call("")).optJSONObject("user_info")
        if (info == null || info.str("auth") == "0") throw Exception("اسم المستخدم أو كلمة المرور خطأ")
        val status = info.str("status")
        if (status.isNotEmpty() && !status.equals("Active", true)) throw Exception("الاشتراك: $status")
        val end = info.str("exp_date").toLongOrNull()
        return if (end == null) "غير محدود" else formatSeconds(end)
    }

    private fun prefix(kind: Kind) = when (kind) {
        Kind.LIVE -> "live"
        Kind.MOVIE -> "vod"
        Kind.SERIES -> "series"
    }

    override fun categories(kind: Kind): List<Category> =
        JSONArray(call("&action=get_${prefix(kind)}_categories")).objects()
            .map { Category(it.str("category_id"), it.str("category_name")) }

    override fun items(kind: Kind, categoryId: String): List<Item> {
        val action = if (kind == Kind.SERIES) "get_series" else "get_${prefix(kind)}_streams"
        val filter = if (categoryId.isEmpty()) "" else "&category_id=${Http.enc(categoryId)}"
        return JSONArray(call("&action=$action$filter")).objects().mapIndexed { i, o ->
            Item(
                id = o.str(if (kind == Kind.SERIES) "series_id" else "stream_id"),
                name = o.str("name"),
                logo = o.str(if (kind == Kind.SERIES) "cover" else "stream_icon"),
                number = o.optInt("num", i + 1),
                categoryId = o.str("category_id"),
                extra = o.str("container_extension"),
                hasArchive = o.optInt("tv_archive", 0) == 1
            )
        }
    }

    override fun episodes(series: Item): List<Item> {
        val root = JSONObject(call("&action=get_series_info&series_id=${Http.enc(series.id)}"))
        val seasons = mutableListOf<JSONArray>()
        val map = root.optJSONObject("episodes")
        if (map != null) {
            map.keys().asSequence().toList().sortedBy { it.toIntOrNull() ?: 0 }
                .forEach { key -> map.optJSONArray(key)?.let { seasons.add(it) } }
        } else {
            val list = root.optJSONArray("episodes")
            if (list != null) for (i in 0 until list.length()) list.optJSONArray(i)?.let { seasons.add(it) }
        }
        return seasons.flatMap { season ->
            season.objects().map {
                Item(
                    id = it.str("id"),
                    name = "S${it.str("season")} E${it.str("episode_num")}  ${it.str("title")}",
                    logo = series.logo,
                    extra = it.str("container_extension")
                )
            }
        }
    }

    override fun link(kind: Kind, item: Item): String {
        val ext = item.extra.ifEmpty { "mp4" }
        return when (kind) {
            Kind.LIVE -> "$base/live/$path/${item.id}.ts"
            Kind.MOVIE -> "$base/movie/$path/${item.id}.$ext"
            Kind.SERIES -> "$base/series/$path/${item.id}.$ext"
        }
    }

    private fun decode(s: String): String =
        try { String(Base64.decode(s, Base64.DEFAULT)) } catch (e: IllegalArgumentException) { s }

    override fun epg(item: Item): List<Program> =
        JSONObject(call("&action=get_short_epg&stream_id=${item.id}&limit=6"))
            .optJSONArray("epg_listings").objects().map {
                val from = it.str("start_timestamp").toLongOrNull() ?: 0
                val to = it.str("stop_timestamp").toLongOrNull() ?: 0
                Program(decode(it.str("title")), "${clock(from)} - ${clock(to)}")
            }

    override fun archive(item: Item): List<Program> =
        JSONObject(call("&action=get_simple_data_table&stream_id=${item.id}"))
            .optJSONArray("epg_listings").objects()
            .filter { it.optInt("has_archive", 0) == 1 }
            .map {
                val from = it.str("start_timestamp").toLongOrNull() ?: 0
                val to = it.str("stop_timestamp").toLongOrNull() ?: 0
                val start = it.str("start")
                Program(decode(it.str("title")), start, start, ((to - from) / 60).toInt())
            }.reversed()

    override fun archiveLink(item: Item, program: Program): String {
        // "2026-11-25 20:00:00" -> "2026-11-25:20-00"
        val s = program.start
        if (s.length < 16) throw Exception("وقت البرنامج غير صالح")
        val stamp = s.substring(0, 10) + ":" + s.substring(11, 13) + "-" + s.substring(14, 16)
        return "$base/timeshift/$path/${program.minutes}/$stamp/${item.id}.ts"
    }
}

object Uri {
    fun part(s: String): String = android.net.Uri.encode(s)
}

class Stalker(private val a: Account) : Source {
    private val root = a.url.trim().trimEnd('/')
        .removeSuffix("/c").removeSuffix("/stalker_portal")
    private var endpoint = ""
    private var token = ""
    private val mac = a.mac.trim().uppercase(Locale.US)

    private fun headers(): Map<String, String> {
        val h = mutableMapOf(
            "User-Agent" to MAG_AGENT,
            "X-User-Agent" to "Model: MAG250; Link: WiFi",
            "Cookie" to "mac=${Http.enc(mac)}; stb_lang=en; timezone=Europe%2FParis",
            "Referer" to "$root/c/"
        )
        if (token.isNotEmpty()) h["Authorization"] = "Bearer $token"
        return h
    }

    private fun raw(url: String, query: String): Any? =
        JSONObject(Http.request("$url?$query&JsHttpRequest=1-xml", headers())).opt("js")

    @Synchronized
    private fun connect() {
        if (token.isNotEmpty()) return
        val candidates = listOf("/portal.php", "/server/load.php", "/stalker_portal/server/load.php")
        var last: Exception? = null
        for (c in candidates) {
            try {
                val js = raw(root + c, "type=stb&action=handshake&token=") as? JSONObject
                val t = js?.str("token") ?: ""
                if (t.isNotEmpty()) {
                    endpoint = root + c
                    token = t
                    raw(endpoint, "type=stb&action=get_profile")
                    return
                }
            } catch (e: Exception) {
                last = e
            }
        }
        throw Exception("تعذر الاتصال بالبوابة: ${last?.message ?: "تحقق من الرابط و MAC"}")
    }

    private fun call(query: String): Any? {
        connect()
        return try {
            raw(endpoint, query)
        } catch (e: Exception) {
            // The token may have expired: handshake again once.
            token = ""
            connect()
            raw(endpoint, query)
        }
    }

    private fun data(js: Any?): List<JSONObject> = when (js) {
        is JSONArray -> js.objects()
        is JSONObject -> js.optJSONArray("data").objects()
        else -> emptyList()
    }

    override fun login(): String {
        connect()
        val info = call("type=account_info&action=get_main_info") as? JSONObject
        if (data(call("type=itv&action=get_genres")).isEmpty()) {
            throw Exception("البوابة رفضت عنوان MAC")
        }
        return info?.str("phone")?.ifEmpty { "غير معروف" } ?: "غير معروف"
    }

    private fun type(kind: Kind) = when (kind) {
        Kind.LIVE -> "itv"
        Kind.MOVIE -> "vod"
        Kind.SERIES -> "series"
    }

    override fun categories(kind: Kind): List<Category> {
        val action = if (kind == Kind.LIVE) "get_genres" else "get_categories"
        return data(call("type=${type(kind)}&action=$action"))
            .filter { it.str("id") != "*" }
            .map { Category(it.str("id"), it.str("title")) }
    }

    private fun logo(s: String): String = when {
        s.isEmpty() || s.startsWith("http") -> s
        s.startsWith("/") -> root + s
        else -> "$root/stalker_portal/misc/logos/320/$s"
    }

    private fun item(o: JSONObject, index: Int) = Item(
        id = o.str("id"),
        name = o.str("name"),
        logo = logo(o.str("logo").ifEmpty { o.str("screenshot_uri") }),
        number = o.str("number").toIntOrNull() ?: (index + 1),
        categoryId = o.str("tv_genre_id").ifEmpty { o.str("category_id") },
        extra = o.str("cmd"),
        hasArchive = false
    )

    override fun items(kind: Kind, categoryId: String): List<Item> {
        if (kind == Kind.LIVE) {
            val all = data(call("type=itv&action=get_all_channels")).mapIndexed { i, o -> item(o, i) }
            return if (categoryId.isEmpty()) all else all.filter { it.categoryId == categoryId }
        }
        // VOD lists are paged. Read at most MAX_PAGES pages.
        val result = mutableListOf<Item>()
        val category = categoryId.ifEmpty { "*" }
        for (page in 1..MAX_PAGES) {
            val js = call("type=${type(kind)}&action=get_ordered_list&category=${Http.enc(category)}&p=$page")
            val list = data(js)
            list.forEach { result.add(item(it, result.size)) }
            val total = (js as? JSONObject)?.str("total_items")?.toIntOrNull() ?: 0
            if (list.isEmpty() || result.size >= total) break
        }
        return result
    }

    override fun episodes(series: Item): List<Item> {
        val seasons = data(call("type=series&action=get_ordered_list&movie_id=${Http.enc(series.id)}&p=1"))
        return seasons.flatMap { season ->
            val numbers = season.optJSONArray("series") ?: JSONArray()
            (0 until numbers.length()).map {
                val n = numbers.optString(it)
                Item(
                    id = season.str("id") + ":" + n,
                    name = "${season.str("name")} - $n",
                    logo = series.logo,
                    extra = season.str("cmd"),
                    episode = n
                )
            }
        }
    }

    override fun link(kind: Kind, item: Item): String {
        val t = if (kind == Kind.LIVE) "itv" else "vod"
        val ep = if (item.episode.isEmpty()) "" else "&series=${item.episode}"
        val js = call("type=$t&action=create_link&cmd=${Http.enc(item.extra)}$ep") as? JSONObject
        val cmd = js?.str("cmd")?.ifEmpty { item.extra } ?: item.extra
        return cmd.trim().split(" ").lastOrNull { it.startsWith("http") }
            ?: throw Exception("البوابة لم ترسل رابط التشغيل")
    }

    override fun epg(item: Item): List<Program> =
        data(call("type=itv&action=get_short_epg&ch_id=${Http.enc(item.id)}&size=6"))
            .map { Program(it.str("name"), "${it.str("t_time")} - ${it.str("t_time_to")}") }

    override fun archive(item: Item): List<Program> = emptyList()

    override fun archiveLink(item: Item, program: Program): String =
        throw Exception("الاستدراك غير مدعوم مع Stalker")

    private companion object {
        const val MAX_PAGES = 20
    }
}

class ActivationError(status: Int, reason: String) : ApiError(status, reason)

object Activation {
    /** Exchanges an activation code for account data from our own server. */
    fun activate(server: String, code: String, device: String): Account {
        val body = JSONObject().put("code", code).put("device_id", device).toString()
        val text = try {
            Http.request(server.trimEnd('/') + "/api/activate", body = body)
        } catch (e: ApiError) {
            val reason = try { JSONObject(e.body).str("error") } catch (x: Exception) { "" }
            throw ActivationError(e.status, reason)
        }
        val o = JSONObject(text)
        return Account(
            type = o.str("type"), name = o.str("name"), url = o.str("url"),
            user = o.str("username"), pass = o.str("password"), mac = o.str("mac"),
            code = code, expiry = o.str("expires")
        )
    }

    fun message(reason: String): String = when (reason) {
        "invalid" -> "الكود غير صحيح"
        "disabled" -> "الكود موقوف"
        "expired" -> "انتهت صلاحية الكود"
        "device_limit" -> "بلغ الكود الحد الأقصى للأجهزة"
        "slow_down" -> "محاولات كثيرة، انتظر قليلا"
        else -> "تعذر التفعيل"
    }
}
