package com.rahmouni.tv

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.view.View
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/** Original golden intro: stadium lights, gold dust, falling crown, shining title. */
class IntroView(context: Context) : View(context) {

    private class Dust(val x: Float, val y: Float, val speed: Float, val size: Float)

    private val dust = List(90) {
        Dust(Random.nextFloat(), Random.nextFloat(), 0.03f + Random.nextFloat() * 0.09f,
            1f + Random.nextFloat() * 3f)
    }
    private val title = "Rahmouni Hocine Tv"
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val crown = Path()
    private var start = 0L

    override fun onDraw(canvas: Canvas) {
        if (start == 0L) start = SystemClock.uptimeMillis()
        val t = (SystemClock.uptimeMillis() - start) / 1000f
        val w = width.toFloat()
        val h = height.toFloat()

        // Night sky
        paint.alpha = 255
        paint.shader = LinearGradient(0f, 0f, 0f, h,
            Color.rgb(4, 7, 30), Color.rgb(12, 28, 80), Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, h, paint)

        // Floodlights
        val glow = ease(t / 1.2f)
        for (x in floatArrayOf(0.08f, 0.92f)) {
            paint.shader = RadialGradient(w * x, h * 0.08f, h * 0.7f,
                Color.argb((170 * glow).toInt(), 190, 220, 255), Color.TRANSPARENT,
                Shader.TileMode.CLAMP)
            canvas.drawRect(0f, 0f, w, h, paint)
        }
        paint.shader = null

        // Gold dust rising
        for (d in dust) {
            val y = (((d.y - t * d.speed) % 1f) + 1f) % 1f
            val a = (120 + 120 * sin(t * 4 + d.x * 20)).toInt().coerceIn(0, 255)
            paint.color = Color.argb(a, 255, 205, 70)
            canvas.drawCircle(d.x * w, y * h, d.size * h / 720f, paint)
        }

        // Crown drops into place
        val drop = ease((t - 0.6f) / 1.2f)
        val s = h * 0.22f
        val cx = w / 2
        val top = -s + (h * 0.18f + s) * drop
        crown.reset()
        crown.moveTo(cx - s * 0.7f, top + s)
        crown.lineTo(cx - s * 0.85f, top + s * 0.2f)
        crown.lineTo(cx - s * 0.35f, top + s * 0.55f)
        crown.lineTo(cx, top)
        crown.lineTo(cx + s * 0.35f, top + s * 0.55f)
        crown.lineTo(cx + s * 0.85f, top + s * 0.2f)
        crown.lineTo(cx + s * 0.7f, top + s)
        crown.close()
        paint.color = Color.WHITE
        paint.shader = gold(top, top + s * 1.2f)
        canvas.drawPath(crown, paint)
        canvas.drawRect(cx - s * 0.7f, top + s * 1.06f, cx + s * 0.7f, top + s * 1.2f, paint)

        // Title with a moving shine
        val show = ease((t - 1.8f) / 1f)
        if (show > 0f) {
            paint.typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
            paint.textAlign = Paint.Align.CENTER
            paint.textSize = h * 0.13f
            val measured = paint.measureText(title)
            paint.textSize *= min(1f, w * 0.88f / measured)
            val y = h * 0.68f + (1 - show) * h * 0.08f
            paint.alpha = (255 * show).toInt()
            paint.shader = gold(y - paint.textSize, y)
            canvas.drawText(title, cx, y, paint)

            val shine = ((t - 2.8f) / 1.5f) * w
            if (t > 2.8f) {
                paint.shader = LinearGradient(shine - w * 0.1f, 0f, shine + w * 0.1f, h * 0.05f,
                    intArrayOf(Color.TRANSPARENT, Color.argb(230, 255, 255, 255), Color.TRANSPARENT),
                    null, Shader.TileMode.CLAMP)
                canvas.drawText(title, cx, y, paint)
            }
        }
        paint.shader = null
        postInvalidateOnAnimation()
    }

    private fun gold(y0: Float, y1: Float) = LinearGradient(0f, y0, 0f, y1,
        intArrayOf(Color.rgb(255, 244, 180), Color.rgb(255, 196, 40), Color.rgb(168, 108, 10)),
        null, Shader.TileMode.CLAMP)

    private fun ease(x: Float): Float {
        val c = x.coerceIn(0f, 1f)
        return 1 - (1 - c) * (1 - c) * (1 - c)
    }
}
