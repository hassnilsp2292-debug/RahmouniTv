package com.rahmouni.tv

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.FrameLayout
import androidx.media3.common.Player

/** Movie and episode player. Resumes where the viewer stopped. */
class PlayerActivity : Activity() {

    private lateinit var video: VideoBox
    private var url = ""
    private var key = ""
    private var started = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val kind = Kind.valueOf(intent.getStringExtra("kind") ?: Kind.MOVIE.name)
        val item = Item(
            id = intent.getStringExtra("id") ?: "",
            name = intent.getStringExtra("name") ?: "",
            extra = intent.getStringExtra("extra") ?: "",
            episode = intent.getStringExtra("episode") ?: ""
        )
        key = "${kind.name}_${item.id}"

        val root = FrameLayout(this)
        video = VideoBox(this)
        video.view.useController = true
        video.view.isFocusable = true
        root.addView(video, FrameLayout.LayoutParams(-1, -1))
        root.addView(Ui.button(this, "⛶ الحجم", Color.argb(150, 0, 60, 160), Color.argb(150, 0, 30, 90)) {
            toast(this, video.nextMode())
        }, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END))
        setContentView(root)
        video.view.requestFocus()

        Task.run(this, { Session.source(this).link(kind, item) }) {
            url = it
            if (started) start()
        }
    }

    private fun start() {
        val p = video.open { toast(this, "تعذر التشغيل: $it") }
        p.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED) {
                    Store.setPosition(this@PlayerActivity, key, 0)
                    finish()
                }
            }
        })
        video.play(url, Store.position(this, key))
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode == KeyEvent.KEYCODE_MENU) {
            if (event.action == KeyEvent.ACTION_DOWN) toast(this, video.nextMode())
            return true
        }
        if (event.keyCode != KeyEvent.KEYCODE_BACK && video.view.dispatchKeyEvent(event)) return true
        return super.dispatchKeyEvent(event)
    }

    override fun onStart() {
        super.onStart()
        started = true
        if (url.isNotEmpty()) start()
    }

    override fun onStop() {
        started = false
        video.player?.let {
            if (it.playbackState != Player.STATE_ENDED && it.currentPosition > 0) {
                Store.setPosition(this, key, it.currentPosition)
            }
        }
        video.release()
        super.onStop()
    }
}
