package com.rahmouni.tv

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import kotlin.random.Random

/** Original background: night stadium in blue and red, floodlights, silhouettes and a gold cup. */
class Stadium : Drawable() {

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun draw(canvas: Canvas) {
        val w = bounds.width().toFloat()
        val h = bounds.height().toFloat()
        val r = Random(7)

        fill(canvas, w, h, LinearGradient(0f, 0f, w, h,
            intArrayOf(Color.rgb(3, 20, 90), Color.rgb(18, 8, 55), Color.rgb(130, 0, 50)),
            null, Shader.TileMode.CLAMP))

        // Crowd in the stands
        for (i in 0 until 900) {
            val x = r.nextFloat() * w
            val y = h * (0.12f + r.nextFloat() * 0.40f)
            p.color = when (i % 4) {
                0 -> Color.argb(120, 40, 110, 255)
                1 -> Color.argb(120, 230, 30, 80)
                2 -> Color.argb(110, 255, 205, 70)
                else -> Color.argb(80, 255, 255, 255)
            }
            canvas.drawCircle(x, y, h * 0.004f, p)
        }

        // Pitch with stripes
        for (i in 0 until 8) {
            p.color = if (i % 2 == 0) Color.rgb(14, 110, 50) else Color.rgb(20, 135, 62)
            canvas.drawRect(w * i / 8, h * 0.54f, w * (i + 1) / 8, h, p)
        }
        p.style = Paint.Style.STROKE
        p.strokeWidth = h * 0.005f
        p.color = Color.argb(160, 255, 255, 255)
        canvas.drawOval(RectF(w * 0.35f, h * 0.58f, w * 0.65f, h * 0.82f), p)
        p.style = Paint.Style.FILL

        // Floodlights
        for (x in floatArrayOf(0.06f, 0.30f, 0.70f, 0.94f)) {
            fill(canvas, w, h, RadialGradient(w * x, h * 0.06f, h * 0.35f,
                Color.argb(190, 210, 235, 255), Color.TRANSPARENT, Shader.TileMode.CLAMP))
        }

        // Four anonymous player silhouettes
        for ((i, x) in floatArrayOf(0.30f, 0.39f, 0.61f, 0.70f).withIndex()) {
            player(canvas, w * x, h * 0.20f, h * 0.36f,
                if (i % 2 == 0) Color.rgb(8, 25, 80) else Color.rgb(90, 0, 40))
        }

        // Gold cup in the middle
        cup(canvas, w / 2, h * 0.19f, h * 0.27f)

        // Darker bottom so that the buttons stay readable
        fill(canvas, w, h, LinearGradient(0f, h * 0.5f, 0f, h, Color.TRANSPARENT,
            Color.argb(190, 3, 5, 30), Shader.TileMode.CLAMP))
    }

    private fun fill(canvas: Canvas, w: Float, h: Float, shader: Shader) {
        p.color = Color.WHITE
        p.shader = shader
        canvas.drawRect(0f, 0f, w, h, p)
        p.shader = null
    }

    private fun player(canvas: Canvas, x: Float, y: Float, s: Float, color: Int) {
        p.color = color
        canvas.drawCircle(x, y + s * 0.12f, s * 0.11f, p)
        val body = Path().apply {
            moveTo(x - s * 0.28f, y + s * 0.30f)
            quadTo(x, y + s * 0.20f, x + s * 0.28f, y + s * 0.30f)
            lineTo(x + s * 0.22f, y + s * 0.72f)
            lineTo(x + s * 0.14f, y + s)
            lineTo(x + s * 0.03f, y + s)
            lineTo(x, y + s * 0.76f)
            lineTo(x - s * 0.03f, y + s)
            lineTo(x - s * 0.14f, y + s)
            lineTo(x - s * 0.22f, y + s * 0.72f)
            close()
        }
        canvas.drawPath(body, p)
    }

    private fun cup(canvas: Canvas, x: Float, y: Float, s: Float) {
        p.color = Color.WHITE
        p.shader = LinearGradient(x - s * 0.4f, y, x + s * 0.4f, y + s,
            intArrayOf(Color.rgb(255, 244, 180), Color.rgb(255, 190, 35), Color.rgb(150, 95, 5)),
            null, Shader.TileMode.CLAMP)
        val bowl = Path().apply {
            moveTo(x - s * 0.30f, y)
            lineTo(x + s * 0.30f, y)
            cubicTo(x + s * 0.28f, y + s * 0.45f, x + s * 0.10f, y + s * 0.55f, x + s * 0.05f, y + s * 0.60f)
            lineTo(x + s * 0.07f, y + s * 0.85f)
            lineTo(x + s * 0.24f, y + s)
            lineTo(x - s * 0.24f, y + s)
            lineTo(x - s * 0.07f, y + s * 0.85f)
            lineTo(x - s * 0.05f, y + s * 0.60f)
            cubicTo(x - s * 0.10f, y + s * 0.55f, x - s * 0.28f, y + s * 0.45f, x - s * 0.30f, y)
            close()
        }
        canvas.drawPath(bowl, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = s * 0.05f
        canvas.drawArc(RectF(x - s * 0.46f, y + s * 0.04f, x - s * 0.16f, y + s * 0.36f), 60f, 220f, false, p)
        canvas.drawArc(RectF(x + s * 0.16f, y + s * 0.04f, x + s * 0.46f, y + s * 0.36f), 260f, 220f, false, p)
        p.style = Paint.Style.FILL
        p.shader = null
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.OPAQUE
}
