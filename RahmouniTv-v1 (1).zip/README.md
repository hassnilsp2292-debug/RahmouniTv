# 👑 Rahmouni Hocine Tv

مشغل IPTV (Xtream و Stalker) للهاتف و Android Box. التطبيق مشغل فقط ولا يحتوي أي قنوات أو اشتراكات.

## المزايا
- واجهة افتتاحية ذهبية بموسيقى أصلية
- دخول بكود تفعيل أو Xtream أو Stalker
- قنوات مباشرة بقائمة مثل الريسيفر، باقات، بحث، مفضلة (ضغطة مطولة)
- خمسة أحجام للشاشة
- أفلام ومسلسلات مع استئناف المشاهدة
- دليل البرامج، تعدد الشاشات (4)، الاستدراك (Xtream فقط)

## بناء التطبيق
**Actions** ← **Build APK** ← حمّل **RahmouniTv-apk**.

## خادم التفعيل (فقط إذا أردت الأكواد)
يحتاج خادما (VPS) أو استضافة تشغّل Python بقرص دائم، وبرابط **HTTPS**.

```
cd server
ADMIN_PASSWORD='ضع-كلمة-قوية' python3 server.py
```
أو بـ Docker:
```
docker build -t rahmouni server
docker run -d -p 127.0.0.1:8080:8080 -v rahmouni:/data -e ADMIN_PASSWORD='ضع-كلمة-قوية' -e TRUST_PROXY=1 rahmouni
```
ثم ضع أمامه وكيلا يوفر HTTPS (مثل Caddy). استعمل `TRUST_PROXY=1` خلف الوكيل فقط.

- لوحة التحكم: `https://your-domain/admin` (المستخدم `admin`)
- اكتب رابط الخادم في `app/src/main/res/values/strings.xml` داخل `activation_server` ثم أعد البناء.

لا ترفع كلمة السر ولا ملف `rahmouni.db` إلى GitHub.
بيانات الاشتراك المرتبطة بالكود تصل إلى جهاز المستخدم، ويمكن لمستخدم متمرس قراءتها.
إيقاف الكود يسري عند فتح الشاشة الرئيسية مع توفر الخادم.
